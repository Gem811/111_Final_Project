# Team member names
# Date
# CptS 111, Fall 2024
# Name of project
# Brief description and/or purpose of project; include sources
# Modules used

print(f'You are going to die in 7 days.') #well thats a bit dark
